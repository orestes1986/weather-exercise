function addToFav() {
//   console.log("Hello from add to fav!!!");
  var title=document.title;
  var url=document.location;
  var ua = navigator.userAgent.toLowerCase();
//   if (ua.indexOf("msie 8") > -1) {
//     external.AddToFavoritesBar(url, title, '');
//   } else {
    try {
      window.external.addFavorite(url, title);
      document.getElementById("favourites-heart").src = "./imgs/big-heart.svg";
    } catch (e) {
//       console.log("window.external.addFavorite ERROR: "+e);
      try {
	window.sidebar.addPanel(title, url, '');
	document.getElementById("favourites-heart").src = "./imgs/big-heart.svg";
      } catch (e) {
// 	console.log("window.sidebar.addPanel ERROR: "+e);
	try {
	  external.AddToFavoritesBar(url, title, '');
	  document.getElementById("favourites-heart").src = "./imgs/big-heart.svg";
	} catch (e) {
// 	  console.log("external.AddToFavoritesBar ERROR: "+e);
	  alert("Please try shortcut Ctrl+D to add to favorite");
	  document.getElementById("favourites-heart").src = "./imgs/heart.svg"
	}
      }
    }
//   }
//   console.log(document.getElementById("favourites-heart").src.split("/")[document.getElementById("favourites-heart").src.split("/").length-1]);
//   if (document.getElementById("favourites-heart").src.split("/")[document.getElementById("favourites-heart").src.split("/").length-1] != "big-heart.svg") {
//     document.getElementById("favourites-heart").src = "./imgs/big-heart.svg";
//   } else {
//     document.getElementById("favourites-heart").src = "./imgs/heart.svg"
//   }
  return false;
}