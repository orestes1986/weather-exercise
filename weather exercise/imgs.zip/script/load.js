$( window ).on('load', function()  {
  for (var i = 0; i < document.getElementsByClassName("js-social-link").length; i++){
//     console.log("Befoah"+document.getElementsByClassName("js-social-link")[i].href);
    document.getElementsByClassName("js-social-link")[i].href += document.location;
//     console.log("Aftah"+document.getElementsByClassName("js-social-link")[i].href);
  }
  setTimeout(function(){
    $('body').addClass('loaded');
  }, 2000);
});
// Google palces api key
// AIzaSyCglfm-MhWqi4IPsb1IhVFb02FtWZpjgBA	
function accessLocation() {
//   console.log("Hey from accessLocation!!");
//   var x = document.getElementById("demo");
  if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(showPosition);
  } else {
//     console.log("Geolocation is not supported by this browser.");
  }
}
function init() {
    var input = document.getElementById('locationType');
    var autocomplete = new google.maps.places.Autocomplete(input);
}
google.maps.event.addDomListener(window, 'load', init);
function showPosition(position) {
  getForcast(position.coords.latitude, position.coords.longitude);
//   console.log("Latitude: " + position.coords.latitude);
//   console.log("Longitude: " + position.coords.longitude);
}
function searchLocation() {
//   console.log("Hey from searchLocation!!");
//   var loc = document.getElementById("locationForm").elements["locationType"].value;
  var loc = document.getElementById("locationType").value;
  getForcast(loc);
//   console.log(loc);
}
function toggleMenu(){
//   console.log("Hey from toggleMenu!!");
  if ($('.js-menu-call').hasClass( "css-menu-call-on" )) {
    $('.js-menu-call').removeClass('css-menu-call-on');
    $('.js-menu-call').addClass('css-menu-call-off');
    $(".js-side-menu").removeClass("css-side-menu-off");
    $('.js-side-menu').addClass('css-side-menu-on');
  } else {
    $('.js-menu-call').removeClass('css-menu-call-off');
    $('.js-menu-call').addClass('css-menu-call-on');
    $(".js-side-menu").removeClass("css-side-menu-on");
    $('.js-side-menu').addClass('css-side-menu-off');
  }
}
$(window).click(function() {
    if(!$(event.target).closest('.js-side-menu').length) {
      if(!$(event.target).closest('.js-menu-call').length) {
// 	console.log("Hey from closeMenu!!");
	if ($('.js-menu-call').hasClass( "css-menu-call-off" )) {
	  $('.js-menu-call').removeClass('css-menu-call-off');
	  $('.js-menu-call').addClass('css-menu-call-on');
	  $(".js-side-menu").removeClass("css-side-menu-on");
	  $('.js-side-menu').addClass('css-side-menu-off');
	}
      }
    }
});
function checKeyFunc(){
//   console.log("Hey from checKeyFunc!!");
  init();
  if(event.keyCode == 13) {
    searchLocation();
  }
  return event.keyCode != 13;
}